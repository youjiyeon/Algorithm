package day0816;

import java.io.*;
import java.util.*;


public class Main_jungol_1828_냉장고_유지연_1 {
	
	static int N;
	// 냉장고 안에 담을 물건 클래스 생성
	static class Thing implements Comparable<Thing>
	{
		int min, max;
		
		public Thing(int min, int max) 
		{
			super();
			this.min = min;
			this.max = max;
		}

		@Override
		public int compareTo(Thing o) {
			int diff = this.max - o.max;
			return diff != 0 ? diff : this.min- o.min;
		}
		
	}

	public static void main(String[] args) throws NumberFormatException, IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		N = Integer.parseInt(br.readLine());
		
		// 냉장고 안에 담을 것 입력 받기
		Thing[] things = new Thing[N];

		for (int i = 0; i < N; i++) 
		{
			st = new StringTokenizer(br.readLine());
			things[i] = new Thing(Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken()));
		}
		
		// 최고 기온 기준으로 정렬(오름차순)
		Arrays.sort(things);
		
		// 정렬 확인
		for(Thing t : things)
			System.out.println(t.max+" "+t.min);
		
		int cnt = N;
		
		// 가장 낮은 최고 기온
		int temp = things[0].max;
		for (int i = 1; i < N; i++) 
		{
			// 최고 기온보다 높은 최저 기온이면 범위벗어남 -> 같은 냉장고 사용 불가
			if(temp>=things[i].min)
			{
				cnt--;
			}
			else
			{
				temp = things[i].max;
				//cnt++;
			}
		}
		
		System.out.println(cnt);
	}
	
	

}
