package project0817;

import java.io.*;
import java.util.*;

public class Main_2961_도영이가만든맛있는음식_유지연 {

	static int N;
	static int min = Integer.MAX_VALUE;
	static boolean[] isSelected; // 요소의 선택여부 판별
	static List<int[]> list = new ArrayList<>();
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		N = Integer.parseInt(br.readLine());
		
		for (int i = 0; i < N; i++) 
		{
			st = new StringTokenizer(br.readLine());
			list.add(new int[] {Integer.parseInt(st.nextToken()),Integer.parseInt(st.nextToken())});
		}
		isSelected = new boolean[N];
		
		powerSet(0);
		System.out.println(min);
	}
	
	public static void powerSet(int cnt) 
	{
		// 기저 조건
		if(cnt==N)
		{
			List<Integer> selectList = new ArrayList<Integer>();
			int c = 0;
			for (int i = 0; i < N; i++) 
			{
				if(isSelected[i])
				{
					selectList.add(i);
				}
				else
					c++;
			}

			// nC0 제거
			if(c!=N)
			{
				Diff(selectList);
			}
			return;
		}
		

		// cnt인덱스 요소를 뽑는 경우
		isSelected[cnt] = true;
		powerSet(cnt+1);
			
		// cnt인덱스 요소를 뽑지 않는 경우
		isSelected[cnt] = false;
		powerSet(cnt+1);
		
	}

	public static void Diff(List<Integer> l) {
		
		int multi = 1;
		int sum = 0;

		for (int i = 0; i < l.size(); i++) 
		{
			multi *= list.get(l.get(i))[0];
			sum += list.get(l.get(i))[1];
		}
		
		min = min > Math.abs(sum-multi) ? Math.abs(sum-multi) : min;
	}

}